package com.example.cinema.services;
import static java.lang.Math.random;

import com.example.cinema.entities.*;
import com.example.cinema.repositories.*;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Random;
import java.util.stream.Stream;

@Service
@Transactional
public class CinemaInitServiceImpl implements ICinemaInit{
    @Autowired //injection des dépendances
    private VilleRepository villeRepository;
    @Autowired //injection des dépendances
    private CinemaRepository cinemaRepository;
    @Autowired //injection des dépendances
    private SalleRepository salleRepository;
    @Autowired //injection des dépendances
    private PlaceRepository placeRepository;
    @Autowired //injection des dépendances
    private SeanceRepository seanceRepository;
    @Autowired //injection des dépendances
    private CategorieRepository categorieRepository;
    @Autowired //injection des dépendances
    private FilmRepository filmRepository;
    @Autowired //injection des dépendances
    private FilmProjectionRepository filmProjectionRepository;
    @Autowired //injection des dépendances
    private TicketPlaceRepository ticketPlaceRepository;


    @Override
    public void initVilles() {
        //définir une liste de villes
        Stream.of("Casablanca","Rabat","Tanger","Marrakech").forEach(nameVille->{
            Ville ville=new Ville();
            ville.setName(nameVille);
            villeRepository.save(ville);
                }
                );

    }
    @Override
    public void initCinemas() {
        villeRepository.findAll().forEach(ville -> {
            //définir une liste de cinémas
            Stream.of("MegaRama", "IMAX", "Daouiliz", "Chahrazad").forEach(nameCinema -> {
                Cinema cinema = new Cinema();
                cinema.setName(nameCinema);
                cinema.setNombreSalles(3+(int)(Math.random()*7));
                cinema.setVille(ville);
                cinemaRepository.save(cinema);
            });
        });
}

    @Override
    public void initSalles() {
        cinemaRepository.findAll().forEach(cinema ->{
            for(int i=0;i<cinema.getNombreSalles();i++){
                Salle salle=new Salle();
                salle.setName("Salle" +(i+1));
                salle.setCinema(cinema);
                salle.setNombrePlace(15+(int)(Math.random()*20));
                salleRepository.save(salle);

            }
        });

    }

    @Override
    public void initPlaces() {
        salleRepository.findAll().forEach(salle->
        {
            for(int i=0;i<salle.getNombrePlace();i++)
            {
                Place place=new Place();
                place.setNumero(i+1);
                place.setSalle(salle);
                placeRepository.save(place);

            }
        });

    }

    @Override
    public void initSeances() {
        DateFormat dateFormat=new SimpleDateFormat("HH:mm");
        Stream.of("12:00","15:00","17:00","19:00","21:00").forEach(s ->{
            Seance seance=new Seance();
            try {
                seance.setHeureDebut(dateFormat.parse(s));
                seanceRepository.save(seance);
            }catch (ParseException e){
                e.printStackTrace();
            }

        });

    }

    @Override
    public void initCategories() {
        Stream.of("Histoire","Actions","Fiction","Drama").forEach(cat->
        {
            Categorie categorie=new Categorie();
            categorie.setName(cat);
            categorieRepository.save(categorie);
        });

    }

    @Override
    public void initFilms() {
        double[] durees=new double[]{1,1,5,2,2,5,3};
        List<Categorie> categories=categorieRepository.findAll();
        Stream.of("12 Hommes en colere","Forset Gump","Green Book","La Ligne Verte","Le Parrain","Le Seigneur des anneaux").
                forEach(titreFilm->
                {
                    Film film=new Film();
                    film.setTitre(titreFilm);
                    film.setDuree(durees[new Random().nextInt(durees.length)]);
                    film.setPhoto(titreFilm.replaceAll("","")+".jpg");
                    film.setCategorie(categories.get(new Random().nextInt(categories.size())));
                    filmRepository.save(film);
                });

    }

    @Override
    public void initFilmProjections() {
        double[] prices=new double[] {30,50,60,70,90,100};
        villeRepository.findAll().forEach(ville -> {
            ville.getCinemas().forEach(cinema -> {
                cinema.getSalles().forEach(salle -> {
                    filmRepository.findAll().forEach(film->
                            {seanceRepository.findAll().forEach(seance -> {
                                FilmProjection filmProjection=new FilmProjection();
                                filmProjection.setDateProjection(new Date());
                                filmProjection.setFilm(film);
                                filmProjection.setPrix(prices[new Random().nextInt(prices.length)]);
                                filmProjection.setSalle(salle);
                                filmProjection.setSeance(seance);
                                filmProjectionRepository.save(filmProjection);
                            });
                            });
                });
            });
        });


    }

    @Override
    public void initTicketsPlace() {
        filmProjectionRepository.findAll().forEach(p->
        {
            p.getSalle().getPlaces().forEach(place -> {

                TicketPlace ticketPlace=new TicketPlace();
                ticketPlace.setPlace(place);
                ticketPlace.setPrix(p.getPrix());
                ticketPlace.setProjection(p);
                ticketPlace.setReserve(false);
                ticketPlaceRepository.save(ticketPlace);
            });
        });


    }
}

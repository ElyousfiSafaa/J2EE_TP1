package com.example.cinema.services;

public interface ICinemaInit {
    public void initVilles();// initialiser les villes
    public void initCinemas();
    public void initSalles();
    public void initPlaces();
    public void initSeances();
    public void initCategories();
    public void initFilms();
    public void initFilmProjections();
    public void initTicketsPlace();

}

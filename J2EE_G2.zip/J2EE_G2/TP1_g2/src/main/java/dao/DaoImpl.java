package dao;


class DaoImpln implements IDao {

    @Override
    public double getData() {
        System.out.println("From SQL DB");
        return (7);

    }
}


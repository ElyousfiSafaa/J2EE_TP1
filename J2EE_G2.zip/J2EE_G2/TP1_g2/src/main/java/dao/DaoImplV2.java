package dao;

import org.springframework.stereotype.Component;

@Component ("dao")
class DaoImplnV2 implements IDao {

    @Override
    public double getData() {
        System.out.println("Version Base de donnée");
        return (7);

    }
}
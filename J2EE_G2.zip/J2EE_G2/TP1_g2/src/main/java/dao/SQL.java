package dao;

public class SQL implements IDao{
    @Override
    public double getData() {
        System.out.println("Version Base de donnée");
        return (10);
    }
}
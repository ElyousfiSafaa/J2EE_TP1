package presentation;
import metier.MetierImpl;
import dao.DaoNSQL;
import dao.SQL;
public class Presentation {
    public static  void main(String[] args)
    {
        MetierImpl metier= new MetierImpl();
        SQL sql= new SQL();

        metier.setDao(sql);
        double resultat= metier.calcul();
        System.out.println("Résultat est =>" + resultat);
    }
}

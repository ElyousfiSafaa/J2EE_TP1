package presentation;

import dao.DaoNSQL;
import metier.IMetier;
import metier.MetierImpl;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class PresentationSpringV2 {

    public static  void main(String[] args)
    {
        ApplicationContext context=new AnnotationConfigApplicationContext("dao","metier");
        // scanner les classes dans les packages dao  & metier
        IMetier metier=context.getBean(IMetier.class);
        System.out.println("R:" + metier.calcul());
    }
}
